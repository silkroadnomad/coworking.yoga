import{a as t}from"../chunks/entry.H5vtNocC.js";export{t as start};
