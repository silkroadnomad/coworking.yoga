import{a as t}from"../chunks/entry.Or9jDBdZ.js";export{t as start};
