import{a as t}from"../chunks/entry.BHAd3WR3.js";export{t as start};
