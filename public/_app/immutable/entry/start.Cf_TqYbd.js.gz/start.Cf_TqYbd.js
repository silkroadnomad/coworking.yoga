import{a as t}from"../chunks/entry.Bb8uvne1.js";export{t as start};
