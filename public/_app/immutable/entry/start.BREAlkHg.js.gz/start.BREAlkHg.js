import{a as t}from"../chunks/entry.DRH03pzc.js";export{t as start};
